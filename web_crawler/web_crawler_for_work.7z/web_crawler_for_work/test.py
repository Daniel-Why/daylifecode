test_ip_list = open("./web_crawler_for_work/test1.txt",mode="r")
for i in test_ip_list:
    bot_name = i.replace("\n","")
    print(bot_name)
    tested_ip_pool= open("./web_crawler_for_work/can_be_used_proxyip_pool.txt",mode="r+")
    tested_ip_pool.seek(0,2)
    tested_ip_pool.write(bot_name+"\n")
tested_ip_pool.close()